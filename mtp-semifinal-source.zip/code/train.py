"""Replay the fixed public-MTP → V1…V8 → V10 route."""
import argparse,fcntl,json
from pathlib import Path
from utils.core import atomic_json,digest
from utils.inputs import inputs
from utils.loading import configure_numeric
from utils.runner import train_chain
import torch

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for k in ['pretrained','images','labels']:p.add_argument('--'+k)
    p.add_argument('--output',required=True);p.add_argument('--resume',action='store_true');a=p.parse_args()
    configure_numeric()
    if not torch.cuda.is_available():raise RuntimeError('CUDA required for full training')
    out=Path(a.output).resolve()
    if out.exists() and any(out.iterdir()) and not a.resume:raise ValueError('use new output or explicit --resume')
    if a.resume and not (out/'arguments.json').exists():raise ValueError('no run to resume')
    out.mkdir(parents=True,exist_ok=True)
    with (out/'run.lock').open('a') as f:
        fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
        cfg=json.loads((Path(__file__).parent/'configs/train.json').read_text())
        if a.resume:
            args=json.loads((out/'arguments.json').read_text())
            if args['config']!=digest(cfg):raise ValueError('configuration changed')
            for k in ['pretrained','images','labels']:
                if getattr(a,k) and str(Path(getattr(a,k)).resolve())!=args[k]:raise ValueError('resume path conflict')
        else:
            if not all(getattr(a,k) for k in ['pretrained','images','labels']):p.error('--pretrained --images --labels required for new training')
            args={k:str(Path(getattr(a,k)).resolve()) for k in ['pretrained','images','labels']};args['config']=digest(cfg);atomic_json(out/'arguments.json',args)
        m=inputs(args['images'],args['labels'])
        train_chain(cfg,m,args['pretrained'],out,a.resume)
if __name__=='__main__':main()
