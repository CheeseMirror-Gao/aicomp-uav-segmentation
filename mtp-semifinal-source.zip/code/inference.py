"""N02_WideDense, FP32, one model, all-one multipliers."""
import argparse,fcntl,hashlib,io,json,os,time,zipfile
from pathlib import Path
import numpy as np
from PIL import Image
import torch
from utils.core import sha,digest,atomic_json,implementation_identity
from utils.inputs import inputs
from utils.data import tensors
from utils.loading import build,configure_numeric
from utils.predict import predict,mask,protocol as numeric_protocol

def png_valid(raw,size):
    with Image.open(io.BytesIO(raw)) as im:
        im.load();a=np.asarray(im)
        if im.mode!='L' or list(im.size)!=size or a.dtype!=np.uint8 or a.min()<1 or a.max()>8:raise ValueError('invalid prediction PNG')

def immutable(path,raw):
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():
        if path.read_bytes()!=raw:raise ValueError('different existing output: '+str(path))
    else:
        temp=path.with_suffix(path.suffix+'.tmp');temp.write_bytes(raw);os.replace(temp,path)

def package(out,names,records):
    path=out/'predictions.zip';target=path if path.exists() else out/'predictions.zip.tmp'
    if not path.exists():
        with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED) as z:
            for name in names:z.write(out/'png'/name,name)
    with zipfile.ZipFile(target) as z:
        if z.namelist()!=names or z.testzip() is not None:raise ValueError('ZIP content/CRC mismatch')
        for name in names:
            raw=z.read(name)
            if hashlib.sha256(raw).hexdigest()!=records[name]['png_sha256']:raise ValueError('ZIP PNG mismatch')
            png_valid(raw,records[name]['size'])
    if target!=path:os.replace(target,path)
    return sha(path)

def run(a):
    configure_numeric()
    if not torch.cuda.is_available():raise RuntimeError('CUDA required')
    out=Path(a.output).resolve()
    if out.exists() and any(out.iterdir()) and not a.resume:raise ValueError('use new output or --resume')
    if a.resume and not (out/'identity.json').exists():raise ValueError('no run to resume')
    m=inputs(a.input);protocol=json.loads((Path(__file__).parent/'configs/inference.json').read_text())
    if protocol!=numeric_protocol():raise ValueError('configuration differs from the fixed N02 numerical protocol')
    identity={'checkpoint':sha(a.checkpoint),'input':digest(m),'protocol':protocol,'implementation':implementation_identity(),'format':'N02-v1'}
    out.mkdir(parents=True,exist_ok=True)
    with (out/'run.lock').open('a') as f:
        fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
        ip=out/'identity.json'
        if ip.exists() and json.loads(ip.read_text())!=identity:raise ValueError('identity mismatch')
        if not ip.exists():atomic_json(ip,identity)
        model=build(a.checkpoint,'cuda');records={}
        for row in m['images']:
            name=row['name'];rp=out/'receipts'/(name+'.json');png=out/'png'/name
            if rp.exists():
                r=json.loads(rp.read_text())
                if r['identity']!=identity or r['input']!=row['image_sha256'] or r['png_sha256']!=sha(png):raise ValueError('receipt conflict/corruption')
                png_valid(png.read_bytes(),row['size']);records[name]=r;continue
            if sha(row['image'])!=row['image_sha256']:raise ValueError('input changed')
            start=time.monotonic();calls=[0]
            def hook(*args):calls[0]+=1
            handle=model.register_forward_hook(hook)
            try:p,n=predict(model,tensors(row))
            finally:handle.remove()
            if row['size']==[1024,1024] and (n,calls[0])!=(28,16):raise ValueError('unexpected calls')
            buf=io.BytesIO();Image.fromarray(mask(p).cpu().numpy(),mode='L').save(buf,format='PNG');raw=buf.getvalue();png_valid(raw,row['size']);immutable(png,raw)
            r={'identity':identity,'input':row['image_sha256'],'size':row['size'],'png_sha256':hashlib.sha256(raw).hexdigest(),'windows':n,'batches':calls[0],'seconds':time.monotonic()-start};atomic_json(rp,r);records[name]=r
            print(name,r['seconds'],flush=True);del p
        h=package(out,[r['name'] for r in m['images']],records);atomic_json(out/'complete.json',{'images':len(records),'zip_sha256':h,'identity':identity})
def main():
    p=argparse.ArgumentParser(description=__doc__)
    for k in ['checkpoint','input','output']:p.add_argument('--'+k,required=True)
    p.add_argument('--resume',action='store_true');run(p.parse_args())
if __name__=='__main__':main()
