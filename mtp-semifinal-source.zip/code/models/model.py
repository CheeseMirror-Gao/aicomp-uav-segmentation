"""MTP RVSA and MMSeg 1.0 UPerNet parameter-compatible CPU implementation."""
import math
import torch
from torch import nn
from torch.nn import functional as F
from .rvsa import RVSA_MTP

def resize(x,size): return F.interpolate(x,size=size,mode='bilinear',align_corners=False)
class ConvModule(nn.Module):
    def __init__(self,a,b,k,padding=0):
        super().__init__(); self.conv=nn.Conv2d(a,b,k,padding=padding,bias=False)
        self.bn=nn.BatchNorm2d(b,eps=1e-5,momentum=.1); self.activate=nn.ReLU(inplace=False)
    def forward(self,x): return self.activate(self.bn(self.conv(x)))
class PPM(nn.ModuleList):
    def __init__(self,cin,c):
        super().__init__([nn.Sequential(nn.AdaptiveAvgPool2d(s),ConvModule(cin,c,1)) for s in (1,2,3,6)])
    def forward(self,x): return [resize(m(x),x.shape[-2:]) for m in self]
class UPerHead(nn.Module):
    def __init__(self,cin=1024,c=512):
        super().__init__(); self.psp_modules=PPM(cin,c)
        self.bottleneck=ConvModule(cin+4*c,c,3,1)
        self.lateral_convs=nn.ModuleList([ConvModule(cin,c,1) for _ in range(3)])
        self.fpn_convs=nn.ModuleList([ConvModule(c,c,3,1) for _ in range(3)])
        self.fpn_bottleneck=ConvModule(4*c,c,3,1)
        self.dropout=nn.Dropout2d(.1); self.conv_seg=nn.Conv2d(c,7,1)
        self.vehicle=None
    def features(self,x):
        lat=[m(v) for m,v in zip(self.lateral_convs,x)]
        lat.append(self.bottleneck(torch.cat([x[-1]]+self.psp_modules(x[-1]),1)))
        for i in (3,2,1): lat[i-1]=lat[i-1]+resize(lat[i],lat[i-1].shape[-2:])
        out=[m(v) for m,v in zip(self.fpn_convs,lat[:3])]+[lat[-1]]
        return self.fpn_bottleneck(torch.cat([out[0]]+[resize(v,out[0].shape[-2:]) for v in out[1:]],1))
    def forward(self,x):
        z=self.dropout(self.features(x)); y=self.conv_seg(z)
        return y if self.vehicle is None else torch.cat([y,self.vehicle(z)],1)
    def expand(self):
        if self.vehicle is not None: raise ValueError('already expanded')
        self.vehicle=nn.Conv2d(self.conv_seg.in_channels,1,1).to(self.conv_seg.weight)
        with torch.no_grad():
            self.vehicle.weight.copy_(self.conv_seg.weight[:1]); self.vehicle.bias.copy_(self.conv_seg.bias[:1]-math.log(100))
class Segmentor(nn.Module):
    def __init__(self):
        super().__init__(); self.backbone=RVSA_MTP(img_size=512,patch_size=16,embed_dim=1024,depth=24,num_heads=16,mlp_ratio=4,qkv_bias=True,out_indices=[7,11,15,23],use_abs_pos_emb=True,interval=6,pretrained=None)
        self.backbone.norm=nn.LayerNorm(1024,eps=1e-6)  # saved legacy parameter, not used by official forward
        self.decode_head=UPerHead(); self.stage=0
    def forward(self,x):
        if x.shape[-2:]!=(512,512): raise ValueError('fixed 512 window required')
        return resize(self.decode_head(self.backbone(x)),x.shape[-2:])
    def set_stage(self,stage):
        self.stage=stage
        for n,p in self.named_parameters():
            active=n.startswith(('decode_head.conv_seg.','decode_head.vehicle.'))
            if stage==2: active=active or n.startswith('decode_head.') or n.startswith('backbone.fpn') or (n.startswith('backbone.blocks.') and int(n.split('.')[2])>=12)
            p.requires_grad_(active); p.grad=None
        self.train(self.training)
    def train(self,mode=True):
        super().train(mode)
        if mode:
            self.backbone.eval()
            if self.stage==2:
                for b in self.backbone.blocks[12:]: b.train()
                for i in range(1,5): getattr(self.backbone,f'fpn{i}').train()
            if self.stage!=2: self.decode_head.eval()
            for m in self.modules():
                if isinstance(m,nn.modules.batchnorm._BatchNorm): m.eval()
        return self
