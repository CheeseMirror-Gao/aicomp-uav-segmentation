import numpy as np
import torch
from .core import sha
ORIGINAL_SHA="9c158de6c645c37158deb16f090c54a22fee1a322d025b7fe1496ff81de9d97e"
class HistoryBuffer:
    """Inert container: no imported MMEngine code or executable state handlers."""

def metadata_getattr(obj, name):
    if obj is not HistoryBuffer or name not in {'min', 'max', 'mean', 'current'}:
        raise ValueError('unexpected legacy metadata reference')
    return None

def restricted_original(path, expected):
    if expected != ORIGINAL_SHA or sha(path) != ORIGINAL_SHA:
        raise ValueError('legacy compatibility requires exact official file SHA')
    allow = [(HistoryBuffer, 'mmengine.logging.history_buffer.HistoryBuffer'), (metadata_getattr, 'builtins.getattr'), (np._core.multiarray._reconstruct, 'numpy.core.multiarray._reconstruct'), (np._core.multiarray.scalar, 'numpy.core.multiarray.scalar'), np.ndarray, np.dtype, np.dtypes.Float64DType, np.dtypes.Int64DType, np.dtypes.Float32DType]
    with torch.serialization.safe_globals(allow):
        return torch.load(path, map_location='cpu', weights_only=True, mmap=True)
