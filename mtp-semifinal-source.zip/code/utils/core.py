import hashlib,json,os,math,random
from pathlib import Path
import numpy as np
import torch
from torch.nn import functional as F

def implementation_identity():
    """Bind new checkpoints to this code, without an external checksum manifest."""
    root=Path(__file__).resolve().parents[1]
    files=list(root.glob('*.py'))
    for name in ('models','utils','configs'):
        files.extend(p for p in (root/name).glob('*') if p.suffix in ('.py','.json'))
    return digest({str(p.relative_to(root)):sha(p) for p in sorted(files)})

def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for b in iter(lambda : f.read(2 ** 20), b''):
            h.update(b)
    return h.hexdigest()

def digest(x):
    return hashlib.sha256(json.dumps(x, sort_keys=True, separators=(',', ':')).encode()).hexdigest()

def atomic_json(p, x):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    t = p.with_suffix(p.suffix + '.tmp')
    t.write_text(json.dumps(x, indent=2, ensure_ascii=False))
    os.replace(t, p)

def atomic_torch(p, x):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    t = p.with_suffix(p.suffix + '.tmp')
    torch.save(x, t)
    os.replace(t, p)

def loss_images(logits, y):
    w = logits.new_tensor([1, 1, 1, 1, 1, 1, 1, 2])
    v = y != 255
    ce = F.cross_entropy(logits, y, weight=w, ignore_index=255, reduction='none')
    denom = w[y.clamp(0, 7)] * v
    return ce.flatten(1).sum(1) / denom.flatten(1).sum(1).clamp_min(1)

def classify_group(n):
    if n.startswith('decode_head.vehicle.'):
        return ('vehicle', 0.0002, False)
    if n.startswith('decode_head.conv_seg.'):
        return ('old', 2e-05, False)
    if n.startswith('decode_head.'):
        return ('uper', 1e-05, True)
    if n.startswith('backbone.fpn'):
        return ('fpn', 5e-06, True)
    if n.startswith('backbone.blocks.') and int(n.split('.')[2]) >= 12:
        i = int(n.split('.')[2])
        return (f'block{i}', 2e-06 * 0.9 ** (23 - i), True)
    return ('frozen', 0.0, True)

def optimizer(model):
    groups = []
    for (n, p) in model.named_parameters():
        (name, base, new) = classify_group(n)
        no_decay = p.ndim <= 1 or any((s in n for s in ('norm', 'pos', 'relative_position')))
        groups.append(dict(params=[p], lr=0.0, weight_decay=0.0 if no_decay else 0.01, group_name=name, base_lr=base, newly_opened=new))
    return torch.optim.AdamW(groups, betas=(0.9, 0.999))

def set_lr(opt, u, ue):
    if ue < 100:
        raise ValueError('formal dataset too small for locked schedule')
    for g in opt.param_groups:
        if u <= ue:
            g['lr'] = {'old': 5e-05, 'vehicle': 0.0005}.get(g['group_name'], 0) * min(1, u / 50)
        else:
            s = u - ue
            T = 4 * ue
            f = 0.1 + 0.45 * (1 + math.cos(math.pi * (s - 1) / (T - 1)))
            g['lr'] = g['base_lr'] * f * (min(1, s / 100) if g['newly_opened'] else 1)

def ema_update(ema, model):
    trainable = {n for (n, p) in model.named_parameters() if p.requires_grad}
    with torch.no_grad():
        for (k, v) in model.state_dict().items():
            x = v.detach().cpu()
            if k in trainable and x.is_floating_point():
                ema[k].mul_(0.99).add_(x, alpha=0.01)
            else:
                ema[k].copy_(x)

def rng_state():
    return {'python': random.getstate(), 'numpy': np.random.get_state()[1].tolist(), 'numpy_full': (np.random.get_state()[0], np.random.get_state()[2:]), 'torch': torch.get_rng_state(), 'cuda': torch.cuda.get_rng_state_all() if torch.cuda.is_available() else []}

def restore_rng(r):
    random.setstate(r['python'])
    np.random.set_state((r['numpy_full'][0], np.array(r['numpy'], dtype=np.uint32), *r['numpy_full'][1]))
    torch.set_rng_state(r['torch'])
    if r['cuda']:
        torch.cuda.set_rng_state_all(r['cuda'])
