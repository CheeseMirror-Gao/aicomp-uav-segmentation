"""N02 only; original 28-window / 16-batch ordering retained exactly."""
import math
import torch
from torch.nn import functional as F

def positions(n):
    return [0] if n <= 512 else sorted(set(range(0, n - 511, 256)) | {n - 512})
from .data import MEAN, STD
SCALES = [0.5, 0.625, 0.75]
WEIGHTS = [0.3, 0.3, 0.4]

def protocol():
    return {'name':'N02_WideDense','crop':512,'scales':SCALES,'weights':WEIGHTS,
            'stride':256,'dense_stride':128,'dense_scale':.75,
            'views':['identity','hflip'],'batch':2,'sigma':128,'center':255.5,
            'gaussian_floor':.001,'precision':'FP32_TF32off','multipliers':[1]*8,
            'window_calls':28,'model_batches':16,
            'fusion':'Gaussian tile logits / inverse / resize / softmax / direction / scale probability',
            'align_corners':False,'antialias':False}

def check_probability(p):
    if p.dtype != torch.float32 or not torch.isfinite(p).all() or (p < 0).any():
        raise ValueError('invalid FP32 probability')
    torch.testing.assert_close(p.sum(0), torch.ones_like(p[0]), atol=1e-06, rtol=1e-05)

def mask(p, b=1.0, a=1.0):
    if not all((math.isfinite(v) and v > 0 for v in (b, a))):
        raise ValueError('invalid multiplier')
    weights = p.new_tensor([1, 1, 1, 1, b, 1, a, 1])[:, None, None]
    return (p * weights).argmax(0).to(torch.uint8) + 1

def wide_gaussian(device):
    t = torch.arange(512, dtype=torch.float32, device=device) - 255.5
    g = torch.exp(-(t[:, None] ** 2 + t[None, :] ** 2) / (2 * 128 ** 2))
    return (g / g.max()).clamp_min(0.001)

def origins(n, step):
    return [0] if n <= 512 else sorted(set(range(0, n - 511, step)) | {n - 512})

def aggregate(cache, coords, h, w, g, reference=False):
    out = g.new_zeros(8, h, w)
    den = g.new_zeros(h, w)
    for (y, x) in coords:
        v = cache[y, x]
        (hh, ww) = v.shape[-2:]
        weight = g[:hh, :ww]
        out[:, y:y + hh, x:x + ww] += v * weight
        den[y:y + hh, x:x + ww] += weight
    if not (den > 0).all():
        raise ValueError('coverage')
    actual = out / den
    return actual

def tiles(model, x, dense=False, audit=False):
    (h, w) = x.shape[-2:]
    old = [(y, z) for y in positions(h) for z in positions(w)]
    new = [(y, z) for y in origins(h, 128) for z in origins(w, 128)] if dense else old
    extra = [p for p in new if p not in old]
    cache = {}
    count = 0
    for group in (old, extra):
        for i in range(0, len(group), 2):
            coords = group[i:i + 2]
            batch = []
            sizes = []
            for (y, z) in coords:
                tile = x[:, y:y + 512, z:z + 512]
                (hh, ww) = tile.shape[-2:]
                sizes.append((hh, ww))
                batch.append(F.pad(tile, (0, 512 - ww, 0, 512 - hh)))
            logits = model(torch.stack(batch))
            if logits.dtype != torch.float32 or logits.shape != (len(coords), 8, 512, 512) or (not torch.isfinite(logits).all()):
                raise ValueError('tile precision/shape/finite')
            for (j, (coord, (hh, ww))) in enumerate(zip(coords, sizes)):
                cache[coord] = logits[j, :, :hh, :ww]
            count += len(coords)
    wide = wide_gaussian(x.device)
    return (aggregate(cache, new, h, w, wide, audit), count)

@torch.inference_mode()
def predict(model, rgb, audit=False):
    if rgb.ndim != 3 or rgb.shape[0] != 3 or min(rgb.shape[-2:]) < 1:
        raise ValueError('RGB CHW')
    if any((p.dtype != torch.float32 for p in model.parameters())):
        raise ValueError('FP32 required')
    model.eval()
    device = next(model.parameters()).device
    rgb = rgb.to(device, dtype=torch.float32)
    (h, w) = rgb.shape[-2:]
    result = rgb.new_zeros(8, h, w)
    count = 0
    total = 0.0
    with torch.autocast(device_type=device.type, enabled=False):
        for (s, sw) in zip(SCALES, WEIGHTS):
            view = F.interpolate(rgb[None], size=[max(1, math.floor(v * s + 0.5)) for v in (h, w)], mode='bilinear', align_corners=False, antialias=False)[0]
            orient = rgb.new_zeros(8, h, w)
            for flip in (False, True):
                x = view.flip(-1) if flip else view
                (l, n) = tiles(model, (x - MEAN.to(device)) / STD.to(device), dense=s == 0.75, audit=audit)
                count += n
                if flip:
                    l = l.flip(-1)
                l = F.interpolate(l[None], size=(h, w), mode='bilinear', align_corners=False, antialias=False)[0]
                orient.add_(l.softmax(0) * 0.5)
            result.add_(orient * sw)
            total += sw
    result = result / total
    check_probability(result)
    if h == w == 1024 and count != 28:
        raise ValueError('call count')
    return (result, count)
