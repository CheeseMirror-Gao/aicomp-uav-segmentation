"""Sequential historical training route, without diagnostics or candidate selection."""
import gc,json,math,os,random,time,uuid
from pathlib import Path
import numpy as np
import torch
from . import core,data,recipes
from .loading import build

class Recovery:
    def __init__(self,directory,identity):
        self.directory=Path(directory);self.directory.mkdir(parents=True,exist_ok=True)
        self.pointer=self.directory/'recovery.json';self.identity=identity
    def save(self,payload):
        previous=json.loads(self.pointer.read_text()) if self.pointer.exists() else None
        if previous and previous['identity']!=self.identity:raise ValueError('recovery ownership conflict')
        name='resume_'+uuid.uuid4().hex+'.pth';path=self.directory/name
        core.atomic_torch(path,{'identity':self.identity,**payload})
        core.atomic_json(self.pointer,{'identity':self.identity,'file':name,'sha256':core.sha(path)})
        if previous:
            old=previous['file']
            if Path(old).name!=old or not old.startswith('resume_'):raise ValueError('unsafe recovery name')
            (self.directory/old).unlink()
    def load(self):
        p=json.loads(self.pointer.read_text())
        if p['identity']!=self.identity or Path(p['file']).name!=p['file']:raise ValueError('recovery identity mismatch')
        path=self.directory/p['file']
        if core.sha(path)!=p['sha256']:raise ValueError('damaged recovery')
        obj=torch.load(path,map_location='cpu',weights_only=True)
        if obj['identity']!=self.identity:raise ValueError('payload identity mismatch')
        return obj

def recipe_for(cfg):
    if cfg['id']=='V1':return None
    config={**cfg,'teacher':cfg['teacher_settings']}
    return getattr(recipes,'RecipeV'+str(cfg['recipe']))(config)

def schedules_for(cfg,names,selected_subset,recipe):
    if recipe is None:return [[(i,'single',False) for i in data.permutation(len(names),c)] for c in range(5)]
    return [recipe.crop_schedule(names,selected_subset,c) for c in range(cfg['cycles'])]

def compute_losses(recipe,logits,y,targets,flags,update):
    if recipe is None:return core.loss_images(logits,y)
    if recipe.config['id'] in ('V2','V3'):return recipe.supervised_and_retention(logits,y,targets,flags)[0]
    return recipe.supervised_and_retention(logits,y,targets,flags,update=update)[0]

def immutable_node(path,obj):
    record=path.with_suffix('.json')
    if record.exists():
        prior=json.loads(record.read_text())
        if prior['identity']!=obj['identity'] or prior['sha256']!=core.sha(path):raise ValueError('saved node corruption/identity conflict')
    if path.exists():
        old=torch.load(path,map_location='cpu',weights_only=True,mmap=True)
        if old['identity']!=obj['identity'] or old['update']!=obj['update'] or old['branch']!=obj['branch'] or old['state_dict'].keys()!=obj['state_dict'].keys() or not all(torch.equal(v.detach().cpu(),old['state_dict'][k]) for k,v in obj['state_dict'].items()):raise ValueError('existing node conflict')
    else:core.atomic_torch(path,obj)
    h=core.sha(path)
    if not record.exists():core.atomic_json(record,{'identity':obj['identity'],'sha256':h})
    return h

def run_stage(model,teacher,cfg,recipe,names,selected_subset,sample,out,identity,device='cuda',resume=False,interrupt=None,fixture=False):
    """Same numerical loop for production and external engineering tests."""
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    random.seed(cfg['seed']);np.random.seed(cfg['seed']);torch.manual_seed(cfg['seed'])
    model=model.to(device)
    if teacher is not None:teacher=teacher.to(device).eval().requires_grad_(False)
    opt=core.optimizer(model) if recipe is None else recipe.make_optimizer(model)
    ema={k:v.detach().cpu().clone() for k,v in model.state_dict().items()}
    schedules=schedules_for(cfg,names,selected_subset,recipe);count=len(schedules[0]);ue=math.ceil(count/16);total=ue*len(schedules)
    if not fixture and total!=cfg['formal_updates']:raise ValueError('training budget mismatch')
    state={'cycle':0,'cursor':0,'update':0};store=Recovery(out,identity)
    if resume:
        r=store.load();state=r['state'];c,cur=state['cycle'],state['cursor']
        if not 0<=c<=len(schedules) or not 0<=cur<=count or (cur!=count and cur%16) or state['update']!=c*ue+math.ceil(cur/16) or (c==len(schedules) and cur!=0):raise ValueError('invalid completed-update cursor')
        if r['schedule']!=core.digest(schedules[c] if c<len(schedules) else []):raise ValueError('schedule mismatch')
        model.load_state_dict(r['model'],strict=True);opt.load_state_dict(r['optimizer']);ema=r['ema'];core.restore_rng(r['rng'])
        for p,values in opt.state.items():
            for k,v in values.items():
                if isinstance(v,torch.Tensor) and k!='step':values[k]=v.to(p.device)
    elif store.pointer.exists():raise ValueError('explicit resume required')
    def save():
        store.save({'state':dict(state),'model':model.state_dict(),'optimizer':opt.state_dict(),'ema':ema,'rng':core.rng_state(),'schedule':core.digest(schedules[state['cycle']] if state['cycle']<len(schedules) else [])})
    if not resume:save()
    while state['cycle']<len(schedules):
        c=state['cycle'];slots=schedules[c]
        if recipe is None:
            model.set_stage(1 if c==0 else 2);model.backbone.use_checkpoint=True
        for begin in range(state['cursor'],count,16):
            start=time.monotonic();model.train();opt.zero_grad(set_to_none=True);batch=slots[begin:begin+16];valid=0;loss_value=0.
            for j in range(0,len(batch),2):
                mini=batch[j:j+2];samples=[sample(c,i,role) for i,role,_ in mini]
                x=torch.stack([s[0] for s in samples]).to(device);y=torch.stack([s[1] for s in samples]).to(device)
                flags=[s[2] for s in mini];targets=None
                if teacher is not None:
                    eligible=torch.as_tensor(flags,device=device,dtype=torch.bool) if cfg['teacher_scope']=='selected_subset' else torch.ones(len(mini),device=device,dtype=torch.bool)
                    if eligible.any():
                        with torch.inference_mode():p=teacher(x[eligible])
                        targets=torch.zeros((len(mini),8,*y.shape[-2:]),device=device);targets[eligible]=p
                        if not torch.isfinite(targets).all():raise ValueError('nonfinite teacher')
                logits=model(x)
                if logits.dtype!=torch.float32 or not torch.isfinite(logits).all():raise ValueError('invalid FP32 logits')
                losses=compute_losses(recipe,logits,y,targets,flags,state['update']+1)
                if not torch.isfinite(losses).all():raise ValueError('nonfinite loss')
                (losses.sum()/len(batch)).backward();valid+=int((y!=255).sum());loss_value+=float(losses.detach().sum())/len(batch)
            if not valid:raise ValueError('no valid supervision in update')
            if any(p.requires_grad and p.grad is None for p in model.parameters()):raise ValueError('missing trainable gradient')
            if recipe is None:
                if fixture:
                    for g in opt.param_groups:g['lr']=.001 if g['group_name']!='frozen' else 0.
                else:core.set_lr(opt,state['update']+1,ue)
            norm=torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad],1.,error_if_nonfinite=True)
            if recipe is not None:
                for g in opt.param_groups:g['lr']=.001 if fixture else g['base_lr']*recipe.lr_factor(state['update']+1,total)
            opt.step();core.ema_update(ema,model);state.update(cursor=begin+len(batch),update=state['update']+1)
            row={'stage':cfg['id'],**state,'loss':loss_value,'grad_norm':float(norm),'lr':{g['group_name']:g['lr'] for g in opt.param_groups},'seconds':time.monotonic()-start}
            with (out/'updates.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
            print(json.dumps(row),flush=True)
            if fixture or state['update']%100==0:save()
            if interrupt:interrupt('update',state)
        # Saving at a completed boundary is transactional; rerun closing after interruption.
        save()
        for branch,sd in [('raw',model.state_dict()),('ema',ema)]:
            immutable_node(out/f'cycle{c+1}_{branch}.pth',{'state_dict':sd,'identity':identity,'cycle':c+1,'update':state['update'],'branch':'raw' if branch=='raw' else 'ema099'})
        if interrupt:interrupt('nodes',state)
        state.update(cycle=c+1,cursor=0);save()
        if interrupt:interrupt('boundary',state)
    final=out/f'cycle{len(schedules)}_ema.pth'
    core.atomic_json(out/'complete.json',{'identity':identity,'updates':total,'file':final.name,'sha256':core.sha(final)})
    return state

def train_chain(cfg,manifest,pretrained,output,resume=False,device='cuda'):
    out=Path(output);names=[r['name'] for r in manifest['images']];selected_subset=set(manifest['selected_names'])
    for stage in cfg['stages']:
        directory=out/stage['id'];parent=Path(pretrained) if stage['parent']=='public' else produced(out/stage['parent'])
        teacher_path=produced(out/stage['teacher']) if stage['teacher'] else None
        identity={'format':'mtp-chain-v1','implementation':core.implementation_identity(),'stage':stage,'parent_sha256':core.sha(parent),'teacher_sha256':core.sha(teacher_path) if teacher_path else None,'data':core.digest(manifest)}
        if (directory/'complete.json').exists():
            done=json.loads((directory/'complete.json').read_text())
            if not resume or done['identity']!=identity or done['sha256']!=core.sha(directory/done['file']):raise ValueError('completed stage conflict')
            continue
        recipe=recipe_for(stage);model=build(parent,public=recipe is None,recipe=recipe)
        teacher=build(teacher_path) if teacher_path else None
        def sample(c,i,role):
            x,y=data.tensors(manifest['images'][i],manifest['label_mapping'])
            return data.augment(x,y,20261030,c,i) if recipe is None else recipe.augment(x,y,c,i,role)
        run_stage(model,teacher,stage,recipe,names,selected_subset,sample,directory,identity,device,resume=resume and (directory/'recovery.json').exists())
        del model,teacher;gc.collect()
        if device.startswith('cuda'):torch.cuda.empty_cache()
    core.atomic_json(out/'complete.json',{'final_model':str(produced(out/'V10')),'sha256':core.sha(produced(out/'V10'))})

def produced(directory):
    done=json.loads((directory/'complete.json').read_text());p=directory/done['file']
    if Path(done['file']).name!=done['file'] or core.sha(p)!=done['sha256']:raise ValueError('stage artifact corrupted')
    return p
