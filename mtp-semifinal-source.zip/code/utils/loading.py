"""Complete-state loading; no historical workspace or network dependency."""
import torch
from torch import nn
from models.model import Segmentor
from .core import sha
from .public_parent import ORIGINAL_SHA,restricted_original


def strict_load(model,sd):
    actual=model.state_dict()
    if not isinstance(sd,dict) or actual.keys()!=sd.keys():raise ValueError('missing or extra model keys')
    for k,v in actual.items():
        if not isinstance(sd[k],torch.Tensor) or v.shape!=sd[k].shape or v.dtype!=sd[k].dtype:raise ValueError('shape/dtype mismatch: '+k)
    model.load_state_dict(sd,strict=True)
    if not all(torch.equal(v.cpu(),sd[k].cpu()) for k,v in model.state_dict().items()):raise ValueError('load mismatch')

class TrainModel(Segmentor):
    def configure(self,recipe):
        self.recipe=recipe
        for n,p in self.named_parameters():p.requires_grad_(recipe.group(n)[0]!='frozen');p.grad=None
        self.backbone.use_checkpoint=recipe.config['id']!='V10'
        self.train(self.training)
    def train(self,mode=True):
        if not hasattr(self,'recipe'):return super().train(mode)
        nn.Module.train(self,mode)
        if self.recipe.config['id']=='V10':self.backbone.eval()
        elif mode:self.backbone.patch_embed.eval()
        if mode:
            for m in self.modules():
                if isinstance(m,nn.modules.batchnorm._BatchNorm):m.eval()
        return self

def build(path,device='cpu',public=False,recipe=None):
    model=TrainModel() if recipe is not None else Segmentor()
    if public:
        obj=restricted_original(path,ORIGINAL_SHA)
        if obj.get('meta',{}).get('iter')!=80000 or 'LoveDADataset' not in obj.get('meta',{}).get('cfg',''):raise ValueError('wrong public task checkpoint')
        strict_load(model,obj['state_dict']);model.decode_head.expand()
    else:
        obj=torch.load(path,map_location='cpu',weights_only=True,mmap=True)
        model.decode_head.expand();strict_load(model,obj.get('state_dict',{}))
    if recipe is not None:model.configure(recipe)
    # Inference keeps requires_grad flags unchanged, as in the final executor.
    return model.to(device).eval()

def configure_numeric():
    torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    torch.set_num_threads(8)
