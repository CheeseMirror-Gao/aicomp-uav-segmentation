import json
from pathlib import Path
import numpy as np
from PIL import Image
from .core import sha
ROOT=Path(__file__).resolve().parents[1]

def inputs(images,labels=None):
    images=Path(images).resolve();labels=Path(labels).resolve() if labels else None
    spec=json.loads((ROOT/'configs/data_order.json').read_text()) if labels else None
    names=spec['names'] if labels else sorted(p.name for p in images.glob('*.png'))
    if not names or len(set(names))!=len(names):raise ValueError('empty/duplicate inputs')
    if labels and ({p.name for p in images.glob('*.png')}!=set(names) or {p.name for p in labels.glob('*.png')}!=set(names)):raise ValueError('official training file set differs from configured order')
    rows=[]
    for name in names:
        if Path(name).name!=name:raise ValueError('unsafe name')
        r={'name':name,'image':str(images/name),'image_sha256':sha(images/name)}
        with Image.open(images/name) as im:
            if im.mode!='RGB':raise ValueError('RGB required: '+name)
            r['size']=list(im.size)
        if labels:
            r.update(label=str(labels/name),label_sha256=sha(labels/name))
            with Image.open(labels/name) as im:
                if list(im.size)!=r['size'] or not set(np.unique(im))<=set(range(9)):raise ValueError('invalid label format: '+name)
        rows.append(r)
    return {'images':rows,**({'label_mapping':spec['label_mapping'],'selected_names':spec['selected_names']} if labels else {})}
