"""Historical update mathematics, with immutable per-stage configurations."""
import hashlib, math
import numpy as np
import torch
from torch.nn import functional as F
from scipy.ndimage import label
from .data import MEAN, STD
from .objective import hard_pixel_ce, blend_ce

class Recipe:

    def __init__(self, config):
        self.config = config

class RecipeV2(Recipe):

    def group(self, name):
        lr = self.config['lr']
        if name.startswith('backbone.blocks.'):
            i = int(name.split('.')[2])
            return (f'block{i}', lr['last_block'] * lr['layer_decay'] ** (23 - i))
        if name.startswith('backbone.fpn'):
            return ('fpn', lr['fpn'])
        if name.startswith('decode_head.vehicle.'):
            return ('vehicle', lr['vehicle'])
        if name.startswith('decode_head.conv_seg.'):
            return ('old', lr['old_classes'])
        if name.startswith('decode_head.'):
            return ('uper', lr['uper'])
        return ('frozen', 0.0)

    def lr_factor(self, update, total):
        warm = self.config['warmup_updates']
        if total <= warm or not 1 <= update <= total:
            raise ValueError('invalid formal update budget')
        if update <= warm:
            return update / warm
        return 0.1 + 0.45 * (1 + math.cos(math.pi * (update - warm) / (total - warm)))

    def make_optimizer(self, model):
        groups = []
        for (name, p) in model.named_parameters():
            (kind, lr) = self.group(name)
            if p.requires_grad != (kind != 'frozen'):
                raise ValueError('trainability mismatch: ' + name)
            if kind == 'frozen':
                continue
            no_decay = p.ndim <= 1 or any((s in name for s in ('norm', 'pos', 'relative_position')))
            groups.append({'params': [p], 'lr': 0.0, 'base_lr': lr, 'group_name': kind, 'parameter_name': name, 'weight_decay': 0.0 if no_decay else self.config['weight_decay']})
        return torch.optim.AdamW(groups, betas=tuple(self.config['betas']))

    def crop_schedule(self, names, selected_names, cycle):
        if len(names) != len(set(names)) or not set(selected_names) <= set(names):
            raise ValueError('bad source identity/scope')
        if not 0 <= cycle < self.config['cycles']:
            raise ValueError('bad cycle')
        slots = []
        for (i, name) in enumerate(names):
            if name in selected_names:
                offset = int(hashlib.sha256(name.encode()).hexdigest()[:8], 16) % 2
                slots.append((i, 'context' if (cycle + offset) % 2 == 0 else 'detail', True))
            else:
                slots.extend([(i, 'context', False), (i, 'detail', False)])
        rng = np.random.default_rng(self.config['seed'] + cycle)
        return [slots[i] for i in rng.permutation(len(slots))]

    def supervised_and_retention(self, student, labels, teacher_logits=None, selected_subset=None):
        if student.ndim != 4 or student.shape[1] != 8 or labels.shape != student.shape[:1] + student.shape[2:]:
            raise ValueError('bad logits/labels')
        valid = labels != 255
        if torch.any(valid & ((labels < 0) | (labels > 7))):
            raise ValueError('bad label')
        weights = student.new_tensor(self.config['loss_weights'])
        ce = F.cross_entropy(student, labels, weight=weights, ignore_index=255, reduction='none')
        denom = (weights[labels.clamp(0, 7)] * valid).flatten(1).sum(1)
        ce = ce.flatten(1).sum(1) / denom.clamp_min(1)
        kd = student.flatten(1).sum(1) * 0.0
        counts = torch.zeros_like(ce, dtype=torch.long)
        if teacher_logits is not None:
            if teacher_logits.shape != student.shape or selected_subset is None:
                raise ValueError('teacher identity/shape missing')
            selected_subset = torch.as_tensor(selected_subset, device=student.device, dtype=torch.bool)
            if selected_subset.shape != (student.shape[0],):
                raise ValueError('bad domain eligibility')
            cfg = self.config['teacher']
            temperature = cfg['temperature']
            with torch.no_grad():
                (conf, pred) = teacher_logits.softmax(1).max(1)
                mask = valid & selected_subset[:, None, None] & (pred == labels) & (conf >= cfg['min_confidence'])
                target = (teacher_logits / temperature).softmax(1)
            divergence = F.kl_div((student / temperature).log_softmax(1), target, reduction='none').sum(1) * temperature ** 2
            counts = mask.flatten(1).sum(1)
            kd = (divergence * mask).flatten(1).sum(1) / counts.clamp_min(1)
        return (ce + self.config['teacher']['weight'] * kd, {'ce': ce.detach(), 'retention': kd.detach(), 'retained_pixels': counts, 'valid_pixels': valid.flatten(1).sum(1)})

    def augment(self, x, y, cycle, index, role):
        if role not in ('context', 'detail'):
            raise ValueError('unknown crop role')
        seed = int(hashlib.sha256(f"{self.config['seed']}:{cycle}:{index}:{role}".encode()).hexdigest()[:16], 16)
        rng = np.random.default_rng(seed)
        guided = role == 'detail' and bool((y == 7).any()) and (rng.random() < 0.5)
        scale = rng.uniform(*self.config[role + '_scale'])
        (h, w) = [max(1, math.floor(v * scale + 0.5)) for v in y.shape]
        x = F.interpolate(x[None], size=(h, w), mode='bilinear', align_corners=False, antialias=False)[0]
        y = F.interpolate(y[None, None].float(), size=(h, w), mode='nearest')[0, 0].long()
        if min(h, w) < 512:
            z = MEAN.expand(3, max(h, 512), max(w, 512)).clone()
            z[:, :h, :w] = x
            x = z
            y = F.pad(y, (0, max(0, 512 - w), 0, max(0, 512 - h)), value=255)
        (h, w) = y.shape
        if guided:
            (labs, n) = label((y == 7).numpy(), structure=np.ones((3, 3)))
            if n == 0:
                raise ValueError('guided vehicle lost')
            points = np.argwhere(labs == rng.integers(1, n + 1))
            (ay, ax) = points[rng.integers(len(points))]
            top = int(rng.integers(max(0, ay - 511), min(ay, h - 512) + 1))
            left = int(rng.integers(max(0, ax - 511), min(ax, w - 512) + 1))
        else:
            top = int(rng.integers(h - 511))
            left = int(rng.integers(w - 511))
        x = x[:, top:top + 512, left:left + 512]
        y = y[top:top + 512, left:left + 512]
        k = int(rng.integers(8))
        x = torch.rot90(x, k % 4, (-2, -1))
        y = torch.rot90(y, k % 4, (-2, -1))
        if k >= 4:
            x = x.flip(-1)
            y = y.flip(-1)
        x = (x * float(rng.uniform(0.9, 1.1))).clamp(0, 255)
        avg = x.mean()
        x = ((x - avg) * float(rng.uniform(0.9, 1.1)) + avg).clamp(0, 255)
        return ((x - MEAN) / STD, y, {'role': role, 'scale': float(scale), 'guided': bool(guided), 'vehicle': bool((y == 7).any()), 'counts': torch.bincount(y[y != 255], minlength=8).tolist()})

class RecipeV3(RecipeV2):

    def make_optimizer(self, model):
        groups = []
        for (name, p) in model.named_parameters():
            (kind, lr) = self.group(name)
            if p.requires_grad != (kind != 'frozen'):
                raise ValueError('trainability mismatch: ' + name)
            if kind == 'frozen':
                continue
            no_decay = p.ndim <= 1 or any((s in name for s in ('norm', 'pos', 'relative_position')))
            groups.append({'params': [p], 'lr': 0.0, 'base_lr': lr, 'group_name': kind, 'parameter_name': name, 'weight_decay': 0.0 if no_decay else self.config['weight_decay']})
        return torch.optim.AdamW(groups, betas=tuple(self.config['betas']), eps=1e-08)

    def crop_schedule(self, names, selected_names, cycle):
        if len(names) != len(set(names)) or not set(selected_names) <= set(names):
            raise ValueError('bad source identity/scope')
        if not 0 <= cycle < self.config['cycles']:
            raise ValueError('bad cycle')
        slots = []
        for (i, name) in enumerate(names):
            if name in selected_names:
                offset = int(hashlib.sha256(name.encode()).hexdigest()[:8], 16) % 2
                slots.append((i, 'context' if (cycle + self.config['cycle_offset'] + offset) % 2 == 0 else 'detail', True))
            else:
                slots.extend([(i, 'context', False), (i, 'detail', False)])
        rng = np.random.default_rng(self.config['seed'] + cycle + self.config['cycle_offset'])
        return [slots[i] for i in rng.permutation(len(slots))]

    def augment(self, x, y, cycle, index, role):
        if role not in ('context', 'detail'):
            raise ValueError('unknown crop role')
        seed = int(hashlib.sha256(f"{self.config['seed']}:{cycle + self.config['cycle_offset']}:{index}:{role}".encode()).hexdigest()[:16], 16)
        rng = np.random.default_rng(seed)
        guided = role == 'detail' and bool((y == 7).any()) and (rng.random() < 0.5)
        scale = rng.uniform(*self.config[role + '_scale'])
        (h, w) = [max(1, math.floor(v * scale + 0.5)) for v in y.shape]
        x = F.interpolate(x[None], size=(h, w), mode='bilinear', align_corners=False, antialias=False)[0]
        y = F.interpolate(y[None, None].float(), size=(h, w), mode='nearest')[0, 0].long()
        if min(h, w) < 512:
            z = MEAN.expand(3, max(h, 512), max(w, 512)).clone()
            z[:, :h, :w] = x
            x = z
            y = F.pad(y, (0, max(0, 512 - w), 0, max(0, 512 - h)), value=255)
        (h, w) = y.shape
        if guided:
            (labs, n) = label((y == 7).numpy(), structure=np.ones((3, 3)))
            if n == 0:
                raise ValueError('guided vehicle lost')
            points = np.argwhere(labs == rng.integers(1, n + 1))
            (ay, ax) = points[rng.integers(len(points))]
            top = int(rng.integers(max(0, ay - 511), min(ay, h - 512) + 1))
            left = int(rng.integers(max(0, ax - 511), min(ax, w - 512) + 1))
        else:
            top = int(rng.integers(h - 511))
            left = int(rng.integers(w - 511))
        x = x[:, top:top + 512, left:left + 512]
        y = y[top:top + 512, left:left + 512]
        k = int(rng.integers(8))
        x = torch.rot90(x, k % 4, (-2, -1))
        y = torch.rot90(y, k % 4, (-2, -1))
        if k >= 4:
            x = x.flip(-1)
            y = y.flip(-1)
        x = (x * float(rng.uniform(0.9, 1.1))).clamp(0, 255)
        avg = x.mean()
        x = ((x - avg) * float(rng.uniform(0.9, 1.1)) + avg).clamp(0, 255)
        return ((x - MEAN) / STD, y, {'role': role, 'scale': float(scale), 'guided': bool(guided), 'vehicle': bool((y == 7).any()), 'counts': torch.bincount(y[y != 255], minlength=8).tolist()})

class RecipeV4(RecipeV3):

    def crop_schedule(self, names, selected_names, cycle):
        if len(names) != len(set(names)) or not set(selected_names) <= set(names):
            raise ValueError('bad source identity/scope')
        if not 0 <= cycle < self.config['cycles']:
            raise ValueError('bad cycle')
        slots = []
        for (i, name) in enumerate(names):
            slots.extend([(i, 'context', name in selected_names), (i, 'detail', name in selected_names)])
        rng = np.random.default_rng(self.config['seed'] + cycle + self.config['cycle_offset'])
        return [slots[i] for i in rng.permutation(len(slots))]

    def lovasz_factor(self, update):
        if update < 1:
            raise ValueError('loss requires the next successful update index')
        return self.config['lovasz']['weight'] * min(1.0, update / self.config['lovasz']['warmup_updates'])

    def lovasz_images(self, probabilities, labels):
        """Per-image present-class Lovasz-Softmax, not batch/global IoU.

    Mathematics follows Berman et al. CVPR2018 (MIT reference implementation).
    Sorting uses a stable order for tied errors. Ignore never enters the ranking.
    """
        values = []
        for (prob, gt) in zip(probabilities, labels):
            valid = gt != 255
            if not valid.any():
                values.append(prob.sum() * 0.0)
                continue
            flat = prob.permute(1, 2, 0)[valid]
            target = gt[valid]
            parts = []
            for c in range(8):
                fg = (target == c).to(flat.dtype)
                if not fg.any():
                    continue
                errors = (fg - flat[:, c]).abs()
                (errors, order) = errors.sort(descending=True, stable=True)
                fg = fg[order]
                total = fg.sum()
                intersection = total - fg.cumsum(0)
                union = total + (1 - fg).cumsum(0)
                jaccard = 1 - intersection / union
                gradient = torch.cat((jaccard[:1], jaccard[1:] - jaccard[:-1]))
                parts.append(torch.dot(errors, gradient))
            values.append(torch.stack(parts).mean())
        return torch.stack(values)

    def supervised_and_retention(self, student, labels, teacher_logits=None, selected_subset=None, update=1):
        if student.ndim != 4 or student.shape[1] != 8 or labels.shape != student.shape[:1] + student.shape[2:]:
            raise ValueError('bad logits/labels')
        valid = labels != 255
        if torch.any(valid & ((labels < 0) | (labels > 7))):
            raise ValueError('bad label')
        weights = student.new_tensor(self.config['loss_weights'])
        ce = F.cross_entropy(student, labels, weight=weights, ignore_index=255, reduction='none')
        denom = (weights[labels.clamp(0, 7)] * valid).flatten(1).sum(1)
        ce = ce.flatten(1).sum(1) / denom.clamp_min(1)
        kd = student.flatten(1).sum(1) * 0.0
        counts = torch.zeros_like(ce, dtype=torch.long)
        if teacher_logits is not None:
            if teacher_logits.shape != student.shape:
                raise ValueError('teacher shape mismatch')
            cfg = self.config['teacher']
            temperature = cfg['temperature']
            with torch.no_grad():
                (conf, pred) = teacher_logits.softmax(1).max(1)
                mask = valid & (pred == labels) & (conf >= cfg['min_confidence'])
                target = (teacher_logits / temperature).softmax(1)
            divergence = F.kl_div((student / temperature).log_softmax(1), target, reduction='none').sum(1) * temperature ** 2
            counts = mask.flatten(1).sum(1)
            per_class = []
            present = []
            for c in range(8):
                selected = mask & (labels == c)
                n = selected.flatten(1).sum(1)
                per_class.append((divergence * selected).flatten(1).sum(1) / n.clamp_min(1))
                present.append(n > 0)
            kd = torch.stack(per_class, 1).sum(1) / torch.stack(present, 1).sum(1).clamp_min(1)
        lovasz = self.lovasz_images(student.softmax(1), labels)
        stats = {'ce': ce.detach(), 'lovasz': lovasz.detach(), 'retention': kd.detach(), 'retained_pixels': counts, 'valid_pixels': valid.flatten(1).sum(1)}
        return (ce + self.lovasz_factor(update) * lovasz + self.config['teacher']['weight'] * kd, stats)

    def augment(self, x, y, cycle, index, role):
        if role not in ('context', 'detail'):
            raise ValueError('unknown crop role')
        seed = int(hashlib.sha256(f"{self.config['seed']}:{cycle + self.config['cycle_offset']}:{index}:{role}".encode()).hexdigest()[:16], 16)
        rng = np.random.default_rng(seed)
        guided_class = None
        if role == 'detail':
            has_vehicle = bool((y == 7).any())
            land = [c for c in self.config['land_guided_classes'] if bool((y == c).any())]
            if has_vehicle:
                if rng.random() < self.config['vehicle_guided_probability_in_detail']:
                    guided_class = 7
            elif land and rng.random() < self.config['land_guided_probability_in_detail']:
                guided_class = int(rng.choice(land))
        guided = guided_class is not None
        scale = rng.uniform(*self.config[role + '_scale'])
        (h, w) = [max(1, math.floor(v * scale + 0.5)) for v in y.shape]
        x = F.interpolate(x[None], size=(h, w), mode='bilinear', align_corners=False, antialias=False)[0]
        y = F.interpolate(y[None, None].float(), size=(h, w), mode='nearest')[0, 0].long()
        if min(h, w) < 512:
            z = MEAN.expand(3, max(h, 512), max(w, 512)).clone()
            z[:, :h, :w] = x
            x = z
            y = F.pad(y, (0, max(0, 512 - w), 0, max(0, 512 - h)), value=255)
        (h, w) = y.shape
        if guided:
            if guided_class == 7:
                (labs, n) = label((y == 7).numpy(), structure=np.ones((3, 3)))
                if n == 0:
                    raise ValueError('guided vehicle lost')
                points = np.argwhere(labs == rng.integers(1, n + 1))
            else:
                points = np.argwhere((y == guided_class).numpy())
            if not len(points):
                raise ValueError('guided land label lost')
            (ay, ax) = points[rng.integers(len(points))]
            top = int(rng.integers(max(0, ay - 511), min(ay, h - 512) + 1))
            left = int(rng.integers(max(0, ax - 511), min(ax, w - 512) + 1))
        else:
            top = int(rng.integers(h - 511))
            left = int(rng.integers(w - 511))
        x = x[:, top:top + 512, left:left + 512]
        y = y[top:top + 512, left:left + 512]
        k = int(rng.integers(8))
        x = torch.rot90(x, k % 4, (-2, -1))
        y = torch.rot90(y, k % 4, (-2, -1))
        if k >= 4:
            x = x.flip(-1)
            y = y.flip(-1)
        x = (x * float(rng.uniform(0.9, 1.1))).clamp(0, 255)
        avg = x.mean()
        x = ((x - avg) * float(rng.uniform(0.9, 1.1)) + avg).clamp(0, 255)
        if guided and (not (y == guided_class).any()):
            raise ValueError('guided anchor missing from final crop')
        return ((x - MEAN) / STD, y, {'role': role, 'scale': float(scale), 'guided': bool(guided), 'guided_class': guided_class, 'vehicle': bool((y == 7).any()), 'counts': torch.bincount(y[y != 255], minlength=8).tolist()})

class RecipeV5(RecipeV4):

    def crop_schedule(self, names, selected_names, cycle):
        if len(names) != len(set(names)) or not set(selected_names) <= set(names):
            raise ValueError('bad source identity/scope')
        if not 0 <= cycle < self.config['cycles']:
            raise ValueError('bad cycle')
        slots = []
        for (i, name) in enumerate(names):
            slots.extend([(i, role, name in selected_names) for role in ('context05', 'context075', 'detail')])
        rng = np.random.default_rng(self.config['seed'] + cycle + self.config['cycle_offset'])
        return [slots[i] for i in rng.permutation(len(slots))]

    def lovasz_factor(self, update):
        if update < 1:
            raise ValueError('loss requires the next successful update index')
        return self.config['lovasz']['weight']

    def augment(self, x, y, cycle, index, role):
        if role not in ('context05', 'context075', 'detail'):
            raise ValueError('unknown crop role')
        seed = int(hashlib.sha256(f"{self.config['seed']}:{cycle + self.config['cycle_offset']}:{index}:{role}".encode()).hexdigest()[:16], 16)
        rng = np.random.default_rng(seed)
        guided_class = None
        if role == 'detail':
            has_vehicle = bool((y == 7).any())
            land = [c for c in self.config['land_guided_classes'] if bool((y == c).any())]
            if has_vehicle:
                if rng.random() < self.config['vehicle_guided_probability_in_detail']:
                    guided_class = 7
            elif land and rng.random() < self.config['land_guided_probability_in_detail']:
                guided_class = int(rng.choice(land))
        guided = guided_class is not None
        scale = rng.uniform(*self.config['detail_scale']) if role == 'detail' else self.config[role + '_scale']
        (h, w) = [max(1, math.floor(v * scale + 0.5)) for v in y.shape]
        x = F.interpolate(x[None], size=(h, w), mode='bilinear', align_corners=False, antialias=False)[0]
        y = F.interpolate(y[None, None].float(), size=(h, w), mode='nearest')[0, 0].long()
        if min(h, w) < 512:
            z = MEAN.expand(3, max(h, 512), max(w, 512)).clone()
            z[:, :h, :w] = x
            x = z
            y = F.pad(y, (0, max(0, 512 - w), 0, max(0, 512 - h)), value=255)
        (h, w) = y.shape
        if guided:
            if guided_class == 7:
                (labs, n) = label((y == 7).numpy(), structure=np.ones((3, 3)))
                if n == 0:
                    raise ValueError('guided vehicle lost')
                points = np.argwhere(labs == rng.integers(1, n + 1))
            else:
                points = np.argwhere((y == guided_class).numpy())
            if not len(points):
                raise ValueError('guided land label lost')
            (ay, ax) = points[rng.integers(len(points))]
            top = int(rng.integers(max(0, ay - 511), min(ay, h - 512) + 1))
            left = int(rng.integers(max(0, ax - 511), min(ax, w - 512) + 1))
        else:
            top = int(rng.integers(h - 511))
            left = int(rng.integers(w - 511))
        x = x[:, top:top + 512, left:left + 512]
        y = y[top:top + 512, left:left + 512]
        k = int(rng.integers(8))
        x = torch.rot90(x, k % 4, (-2, -1))
        y = torch.rot90(y, k % 4, (-2, -1))
        if k >= 4:
            x = x.flip(-1)
            y = y.flip(-1)
        x = (x * float(rng.uniform(0.9, 1.1))).clamp(0, 255)
        avg = x.mean()
        x = ((x - avg) * float(rng.uniform(0.9, 1.1)) + avg).clamp(0, 255)
        if guided and (not (y == guided_class).any()):
            raise ValueError('guided anchor missing from final crop')
        return ((x - MEAN) / STD, y, {'role': role, 'scale': float(scale), 'guided': bool(guided), 'guided_class': guided_class, 'vehicle': bool((y == 7).any()), 'counts': torch.bincount(y[y != 255], minlength=8).tolist()})

class RecipeV6(RecipeV5):

    def supervised_and_retention(self, student, labels, teacher_logits=None, selected_subset=None, update=1):
        if student.ndim != 4 or student.shape[1] != 8 or labels.shape != student.shape[:1] + student.shape[2:]:
            raise ValueError('bad logits/labels')
        valid = labels != 255
        if torch.any(valid & ((labels < 0) | (labels > 7))):
            raise ValueError('bad label')
        weights = student.new_tensor(self.config['loss_weights'])
        ce = F.cross_entropy(student, labels, weight=weights, ignore_index=255, reduction='none')
        denom = (weights[labels.clamp(0, 7)] * valid).flatten(1).sum(1)
        ce = ce.flatten(1).sum(1) / denom.clamp_min(1)
        kd = student.flatten(1).sum(1) * 0.0
        counts = torch.zeros_like(ce, dtype=torch.long)
        if teacher_logits is not None:
            if teacher_logits.shape != student.shape:
                raise ValueError('teacher shape mismatch')
            cfg = self.config['teacher']
            temperature = cfg['temperature']
            with torch.no_grad():
                (conf, pred) = teacher_logits.softmax(1).max(1)
                mask = valid & (pred == labels) & (conf >= cfg['min_confidence'])
                target = (teacher_logits / temperature).softmax(1)
            divergence = F.kl_div((student / temperature).log_softmax(1), target, reduction='none').sum(1) * temperature ** 2
            counts = mask.flatten(1).sum(1)
            per_class = []
            present = []
            for c in range(8):
                selected = mask & (labels == c)
                n = selected.flatten(1).sum(1)
                per_class.append((divergence * selected).flatten(1).sum(1) / n.clamp_min(1))
                present.append(n > 0)
            kd = torch.stack(per_class, 1).sum(1) / torch.stack(present, 1).sum(1).clamp_min(1)
        lovasz = self.lovasz_images(student.softmax(1), labels)
        (hard, hard_counts) = hard_pixel_ce(student, labels) if self.config['hard_alpha'] else (ce, torch.zeros((len(labels), 8), dtype=torch.long, device=labels.device))
        mixed = blend_ce(ce, hard, self.config['hard_alpha'])
        stats = {'hard_ce': hard.detach(), 'hard_counts': hard_counts.detach(), 'mixed_ce': mixed.detach(), 'ce': ce.detach(), 'lovasz': lovasz.detach(), 'retention': kd.detach(), 'retained_pixels': counts, 'valid_pixels': valid.flatten(1).sum(1)}
        return (mixed + self.lovasz_factor(update) * lovasz + self.config['teacher']['weight'] * kd, stats)

class RecipeV8(RecipeV6):
    pass

class RecipeV10(RecipeV8):

    def group(self, name):
        lr = self.config['lr']
        if name.startswith('backbone.'):
            return ('frozen', 0.0)
        if name.startswith('decode_head.vehicle.'):
            return ('vehicle', lr['vehicle'])
        if name.startswith('decode_head.conv_seg.'):
            return ('old', lr['old_classes'])
        if name.startswith('decode_head.'):
            return ('uper', lr['uper'])
        return ('frozen', 0.0)

    def supervised_and_retention(self, student, labels, teacher_logits=None, selected_subset=None, update=1):
        if student.ndim != 4 or student.shape[1] != 8 or labels.shape != student.shape[:1] + student.shape[2:]:
            raise ValueError('bad logits/labels')
        valid = labels != 255
        if torch.any(valid & ((labels < 0) | (labels > 7))):
            raise ValueError('bad label')
        weights = student.new_tensor(self.config['loss_weights'])
        ce = F.cross_entropy(student, labels, weight=weights, ignore_index=255, reduction='none')
        denom = (weights[labels.clamp(0, 7)] * valid).flatten(1).sum(1)
        ce = ce.flatten(1).sum(1) / denom.clamp_min(1)
        kd = student.flatten(1).sum(1) * 0.0
        counts = torch.zeros_like(ce, dtype=torch.long)
        if teacher_logits is not None:
            if teacher_logits.shape != student.shape:
                raise ValueError('teacher shape mismatch')
            cfg = self.config['teacher']
            temperature = cfg['temperature']
            with torch.no_grad():
                (conf, pred) = teacher_logits.softmax(1).max(1)
                mask = valid & (pred == labels) & (conf >= cfg['min_confidence'])
                target = (teacher_logits / temperature).softmax(1)
            divergence = F.kl_div((student / temperature).log_softmax(1), target, reduction='none').sum(1) * temperature ** 2
            counts = mask.flatten(1).sum(1)
            per_class = []
            present = []
            for c in range(8):
                selected = mask & (labels == c)
                n = selected.flatten(1).sum(1)
                per_class.append((divergence * selected).flatten(1).sum(1) / n.clamp_min(1))
                present.append(n > 0)
            kd = torch.stack(per_class, 1).sum(1) / torch.stack(present, 1).sum(1).clamp_min(1)
        lovasz = self.lovasz_images(student.softmax(1), labels)
        (hard, hard_counts) = hard_pixel_ce(student, labels, weights=self.config['loss_weights']) if self.config['hard_alpha'] else (ce, torch.zeros((len(labels), 8), dtype=torch.long, device=labels.device))
        mixed = blend_ce(ce, hard, self.config['hard_alpha'])
        stats = {'hard_ce': hard.detach(), 'hard_counts': hard_counts.detach(), 'mixed_ce': mixed.detach(), 'ce': ce.detach(), 'lovasz': lovasz.detach(), 'retention': kd.detach(), 'retained_pixels': counts, 'valid_pixels': valid.flatten(1).sum(1)}
        return (mixed + self.lovasz_factor(update) * lovasz + self.config['teacher']['weight'] * kd, stats)
