import math
from pathlib import Path
import numpy as np
import torch
from torch.nn import functional as F
from PIL import Image
from scipy.ndimage import label
from .core import digest
MEAN=torch.tensor([123.675,116.28,103.53])[:,None,None]
STD=torch.tensor([58.395,57.12,57.375])[:,None,None]
def tensors(r, mapping=None):
    x = torch.from_numpy(np.array(Image.open(r['image']), copy=True)).permute(2, 0, 1).float()
    if mapping is None:
        return x
    a = np.array(Image.open(r['label']))
    y = np.full(a.shape, 255, np.int64)
    for (k, v) in mapping.items():
        y[a == int(k)] = v
    return (x, torch.from_numpy(y))

def augment(x, y, seed, epoch, index):
    g = np.random.default_rng(int(digest([seed, epoch, index])[:16], 16))
    guided = bool((y == 7).any() and g.random() < 0.5)
    scale = g.uniform(1, 1.25) if guided else g.uniform(0.75, 1.25)
    (h, w) = [max(1, math.floor(v * scale + 0.5)) for v in y.shape]
    x = F.interpolate(x[None], size=(h, w), mode='bilinear', align_corners=False, antialias=False)[0]
    y = F.interpolate(y[None, None].float(), size=(h, w), mode='nearest')[0, 0].long()
    if h < 512 or w < 512:
        z = MEAN.expand(3, max(h, 512), max(w, 512)).clone()
        z[:, :h, :w] = x
        x = z
        y = F.pad(y, (0, max(0, 512 - w), 0, max(0, 512 - h)), value=255)
    (h, w) = y.shape
    if guided:
        (labs, n) = label((y == 7).numpy(), structure=np.ones((3, 3)))
        if n == 0:
            raise ValueError('vehicle disappeared during guided resize')
        points = np.argwhere(labs == g.integers(1, n + 1))
        (ay, ax) = points[g.integers(len(points))]
        top = int(g.integers(max(0, ay - 511), min(ay, h - 512) + 1))
        left = int(g.integers(max(0, ax - 511), min(ax, w - 512) + 1))
    else:
        top = int(g.integers(h - 511))
        left = int(g.integers(w - 511))
    x = x[:, top:top + 512, left:left + 512]
    y = y[top:top + 512, left:left + 512]
    k = int(g.integers(8))
    x = torch.rot90(x, k % 4, (-2, -1))
    y = torch.rot90(y, k % 4, (-2, -1))
    if k >= 4:
        x = x.flip(-1)
        y = y.flip(-1)
    x = (x * float(g.uniform(0.9, 1.1))).clamp(0, 255)
    avg = x.mean()
    x = ((x - avg) * float(g.uniform(0.9, 1.1)) + avg).clamp(0, 255)
    return ((x - MEAN) / STD, y, {'guided': guided, 'counts': torch.bincount(y[y != 255], minlength=8).tolist(), 'vehicle': bool((y == 7).any())})

def permutation(n, epoch):
    return np.random.default_rng(20261030 + epoch).permutation(n).tolist()
