"""Bounded hard-pixel CE: original CE budget is redistributed, not enlarged."""
import math
import torch
from torch.nn import functional as F

def hard_pixel_ce(logits, labels, fraction=.25,weights=(1,1,1,1,1,1,1,2)):
    if logits.ndim != 4 or logits.shape[1] != 8 or labels.shape != logits.shape[:1]+logits.shape[2:]:
        raise ValueError('eight-class logits/labels shape mismatch')
    if not 0 < fraction <= 1 or not torch.isfinite(logits).all():
        raise ValueError('invalid fraction or nonfinite logits')
    valid=labels!=255
    if ((labels[valid]<0)|(labels[valid]>7)).any():
        raise ValueError('invalid labels')
    raw=F.cross_entropy(logits,labels,ignore_index=255,reduction='none')
    weights=logits.new_tensor(weights)
    if weights.shape!=(8,) or not torch.isfinite(weights).all() or not (weights>0).all():raise ValueError("invalid class weights")
    losses=[];counts=[]
    for loss,gt in zip(raw,labels):
        loss=loss.flatten();gt=gt.flatten();picked=[];numbers=[]
        for c in range(8):
            positions=(gt==c).nonzero(as_tuple=True)[0]
            k=math.ceil(fraction*positions.numel())
            if k:
                order=torch.argsort(loss[positions].detach(),descending=True,stable=True)
                picked.append(positions[order[:k]])
            numbers.append(k)
        counts.append(numbers)
        if not picked:
            losses.append(loss.sum()*0)
        else:
            pos=torch.cat(picked);w=weights[gt[pos]]
            losses.append((loss[pos]*w).sum()/w.sum())
    return torch.stack(losses),torch.tensor(counts,device=labels.device)

def blend_ce(ordinary,hard,alpha):
    if not 0<=alpha<=1:raise ValueError('invalid hard fraction')
    if ordinary.shape!=hard.shape:raise ValueError('loss shape mismatch')
    return ordinary if alpha==0 else (1-alpha)*ordinary+alpha*hard
