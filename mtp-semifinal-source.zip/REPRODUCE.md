# MTP 图像语义分割提交材料

本目录提供分阶段训练及推理代码。以下命令中的数据和模型权重路径需指向本地准备的文件。模型为 MTP ViT-L/RVSA + UPerNet，输出八类。推理使用一个模型及同一协议，不使用来源路由或测试时参数自适应。

## 目录

```text
code/
  train.py                  完整训练入口及断点恢复
  inference.py              最终 N02_WideDense 推理与打包
  environment.yml           Linux CUDA 环境
  configs/                  阶段配置、训练数据顺序、推理配置
  models/                   RVSA、UPerNet、八类分类头
  utils/                    必要的数据、损失、训练、恢复和推理实现
  THIRD_PARTY_NOTICES.md     第三方来源及许可证
checkpoints/final_model.pth  推理所需的外部权重路径示例
predictions/predictions.zip  原赛事预测包路径示例
```

原赛事包仅附一份最终模型权重。训练时需要的中间阶段权重由训练程序生成，不需要另行提供历史私有节点。训练诊断、内部评测器、参考标签及验收脚本不包含在本目录。

## 环境

使用 Linux、NVIDIA CUDA GPU，原运行硬件为 RTX 5090 32GB。模型和训练计算为 FP32，关闭 autocast 和 TF32。训练 micro-batch 为 2，累积 8 次，正常有效 batch 为 16；最后不足 16 张时按实际张数归一化。

```bash
conda env create -f code/environment.yml
conda activate mtp-v10
```

环境按原运行的 Python 3.12.3、PyTorch 2.7.1 CUDA 12.8 固定。需要兼容的 NVIDIA 驱动。完整训练会保留各阶段节点及当前恢复文件，须为训练输出准备足够磁盘空间；GPU、CPU 内存及磁盘不足时报错，应先补足资源，不应自行降低精度或改变 batch。

## 数据与公开起点

仅使用赛事提供的训练数据。目录直接放 PNG，不嵌套子目录：

```text
/path/train/images/0000.png ...
/path/train/labels/0000.png ...
/path/test/test3_1.png ...
```

训练图为 RGB，标签为单通道，图像和标签同名、同尺寸。原始标签 0 忽略，1—8 对应：Background、Building、Road、Water、Barren、Vegetation、Agricultural、Vehicle。内部编码为 0—7、ignore255；预测 PNG 编码恢复为 1—8。

从6996张官方训练图像中选取2522张，形成固定训练子集，用于V2、V3阶段的采样安排和教师约束。具体名单随配置提供，其余训练图像仍参与训练。`code/configs/data_order.json` 保存训练图像顺序、固定子集名单和标签映射。不另划验证集，不读取测试标签。

公开起点是 **MTP 官方 Semantic Segmentation → LoveDA → ViT-L + RVSA + UPerNet 完整微调权重**，不是 encoder-only 权重：

- 官方仓库：https://github.com/ViTAE-Transformer/MTP
- 官方语义分割权重目录：https://1drv.ms/f/s!AiSncQLqo7V6gVGc75VWbetEGbZ0?e=VawLcI
- 官方备用入口：https://pan.baidu.com/s/1H0ZaPRcxfuyVLjK5hrsSQw?pwd=udv5
- 本实现对应的原始文件 SHA256：`9c158de6c645c37158deb16f090c54a22fee1a322d025b7fe1496ff81de9d97e`

该 SHA 是对所使用公开文件计算的身份，不声称为官方公布的哈希。下载后将原始完整 `.pth` 传给 `--pretrained`；程序使用受限反序列化读取旧框架元数据，严格检查七类模型键、形状及 dtype，然后扩展车辆分类层。原七类继承，车辆权重复制 Background，bias 减去 ln(100)，参数独立存储。原 Forest 参数行用于 Vegetation 初始化。

## 完整训练

在本目录运行：

```bash
python code/train.py \
  --pretrained /path/to/public_loveda_full.pth \
  --images /path/train/images \
  --labels /path/train/labels \
  --output /path/to/new_training_output
```

入口依次执行下列固定路线；每阶段新建优化器并从指定学生节点初始化 EMA。教师为独立冻结模型，学生和教师来源分别绑定。后续加载本次训练生成的 EMA，不要求重新训练的 SHA 与历史权重相同。

| 阶段 | 学生初始化 | 固定教师 | 周期/轮 | 更新数 |
|---|---|---|---:|---:|
| V1 | 公开 LoveDA 完整权重 | 无 | 5 | 2190 |
| V2 | V1 第5轮 EMA | V1 第5轮 EMA | 4 | 2868 |
| V3 | V2 第4周期 EMA | V1 第5轮 EMA | 2 | 1434 |
| V4 | V3 第2周期 EMA | V3 第2周期 EMA | 2 | 1750 |
| V5 | V4 第2周期 EMA | V4 第2周期 EMA | 1 | 1312 |
| V6 | V5 EMA | V5 EMA | 1 | 1312 |
| V7 | V6 EMA | V6 EMA | 1 | 1312 |
| V8 | V7 EMA | V7 EMA | 1 | 1312 |
| V10 | V8 EMA | V8 EMA | 1 | 1312 |

V9不属于最终父链，不执行。V7采用实际运行配置，历史路线已经固定，不再执行候选比较或自动选点。

训练要点如下，具体值见 `code/configs/train.json` 和 `utils/recipes.py`：

- V1首轮仅分类层训练；后四轮开放后12个骨干块、四尺度变换及任务头。其余阶段除V10外训练24个块及任务侧，patch、绝对位置和未使用的 legacy norm冻结；V10只训练任务头。
- 全程固定 BN 运行统计、关闭 DropPath。V1首轮关闭任务头 dropout，其余阶段为0.1。
- V1逐图完整遍历；V2/V3对固定训练子集与其余训练图安排相应的context/detail曝光；V4每图两视图；V5以后每图context0.5、context0.75和detail三视图。数据顺序、周期偏移及裁剪随机种子固定。
- 数据增强包括512裁剪、D4、温和亮度/对比度、按阶段规定的车辆/裸地/农业引导。图像插值、标签映射和 RGB 归一化保持原训练计算。
- V1加权CE；V2/V3在固定训练子集加入GT正确且置信度达标的教师KL；V4起使用按类别平衡的教师KL及Lovász；V6起按阶段配置混合困难像素CE。V10车辆CE权重为1.5，其余阶段为2。
- AdamW、参数组LR、逐层衰减、warmup、余弦、clip1.0及EMA0.99按阶段配置执行。尾部按实际batch图像数计算；全ignore图贡献零损失，整次更新无有效监督则停止。

训练输出保存各周期 Raw/EMA、必要进度、实际父/教师/数据身份，以及模型、优化器、EMA、随机状态和已消费游标。每100次成功更新及周期边界原子更新恢复文件。恢复文件只兼容本精简版，不兼容历史实验断点。

```bash
python code/train.py --output /path/to/new_training_output --resume
```

最终节点为 `V10/cycle1_ema.pth`。训练全过程必须保留前序产物供教师及后续初始化读取。这里只提交最终权重，不意味着训练过程不生成中间权重。

## 最终预测

使用单份最终权重运行推理：

```bash
python code/inference.py \
  --checkpoint checkpoints/final_model.pth \
  --input /path/test \
  --output /path/to/new_prediction_output
```

断点继续时在相同命令末尾增加 `--resume`。仅在输入、模型、协议及已完成PNG身份一致时跳过；不同内容同名文件和损坏文件报错。

N02_WideDense固定设置：512窗口，尺度0.5/0.625/0.75，尺度权重0.3/0.3/0.4，各identity与水平翻转；前两尺度步长256，0.75尺度额外补入步长128窗口。保留原窗口顺序及batch2组成。Gaussian中心255.5、sigma128，二维最大值归一后截断至1e-3。窗口加权logits平均→逆翻转→恢复原尺寸→softmax→方向平均→尺度概率融合→全1 argmax。每张1024×1024图为28个逻辑窗口、16次模型batch调用。图像和logits双线性插值，align_corners=False、antialias=False。

输出目录含逐图PNG、必要恢复receipt及 `predictions.zip`。ZIP根目录只有输入同名预测PNG；赛事Test3为3594张 `test3_1.png` 至 `test3_3594.png`，每张1024×1024、L模式uint8、标签1—8。

## 复现范围

本材料提供从公开权重开始的实际训练流程及固定父链。GPU采样与浮点反向可能存在非确定性，不承诺重新训练获得逐字节相同权重。使用所附最终权重进行预测复现与完整重新训练是两件事；推理保持原环境和数值路径。多尺度、翻转属于推理增强，未进行测试时参数更新。不包含官方成绩声明。
